Original procedural narcissus / mature model

Keep OBJ and MTL together when importing into Blender.
992 vertices, 1544 triangles, six tepals, corona, throat, stem and leaves.
The static OBJ does not contain animation. The Unity project creates the same
geometry with NarcissusModel.cs and animates it over 21 seconds after skin entry.
